import numpy as np
from scipy import signal

HR_MIN_HZ = 0.75  # 45 BPM
HR_MAX_HZ = 2.5   # 150 BPM

def calculate_hr(pos_signal, fps, previous_hr_bpm=None, lost_lock_counter=0):
    pos_detrended = signal.detrend(pos_signal)
    
    # Tight bandpass
    b_filt, a_filt = signal.butter(3, [HR_MIN_HZ, HR_MAX_HZ], btype='bandpass', fs=fps)
    clean_pulse = signal.filtfilt(b_filt, a_filt, pos_detrended)
    
    current_len = len(clean_pulse)
    safe_nfft = max(2048, current_len)
    freqs, psd = signal.welch(clean_pulse, fs=fps, nperseg=current_len, nfft=safe_nfft)

    peaks, properties = signal.find_peaks(psd, prominence=np.max(psd) * 0.15)
    valid_mask = (freqs[peaks] >= HR_MIN_HZ) & (freqs[peaks] <= HR_MAX_HZ)
    
    candidates = freqs[peaks][valid_mask] * 60.0
    prominences = properties['prominences'][valid_mask]

    graph_mask = (freqs >= HR_MIN_HZ) & (freqs <= HR_MAX_HZ)
    spectrum = {
        "bpm": (freqs[graph_mask] * 60.0).tolist(),
        "power": psd[graph_mask].tolist()
    }

    if len(candidates) == 0:
        return previous_hr_bpm, clean_pulse, lost_lock_counter + 1, spectrum

    # ---------------------------------------------------------
    # 1. STRICT INITIAL LOCK
    # ---------------------------------------------------------
    if previous_hr_bpm is None or lost_lock_counter > 5:
        sorted_indices = np.argsort(prominences)[::-1]
        
        for idx in sorted_indices:
            candidate_hr = candidates[idx]
            candidate_power = prominences[idx]
            
            # Initial lock must be perfectly within standard resting limits
            if 55.0 <= candidate_hr <= 105.0:
                # Must be an incredibly dominant frequency to establish the first lock
                if candidate_power > (np.max(psd) * 0.35): 
                    return candidate_hr, clean_pulse, 0, spectrum
        
        return previous_hr_bpm, clean_pulse, lost_lock_counter + 1, spectrum

    # ---------------------------------------------------------
    # 2. THE HARD-LATCH TRACKER (+/- 1.5 BPM)
    # ---------------------------------------------------------
    # Jumps are permanently disabled. The engine can ONLY move if a valid 
    # peak appears within 1.5 BPM of the current lock.
    
    valid_jump_mask = (candidates >= previous_hr_bpm - 1.5) & (candidates <= previous_hr_bpm + 1.5)
    tethered_candidates = candidates[valid_jump_mask]
    tethered_prominences = prominences[valid_jump_mask]
    
    if len(tethered_candidates) > 0:
        best_idx = np.argmax(tethered_prominences)
        raw_hr = tethered_candidates[best_idx]
        
        # Micro-jitter dead-band (prevents the screen from flickering by 0.1 BPM)
        if abs(raw_hr - previous_hr_bpm) <= 0.5:
            return previous_hr_bpm, clean_pulse, 0, spectrum
        
        # Smooth EMA transition for the tiny variance allowed
        final_hr = (0.90 * previous_hr_bpm) + (0.10 * raw_hr)
        return final_hr, clean_pulse, 0, spectrum
    
    # ---------------------------------------------------------
    # 3. COASTING MODE (No Escape Hatches)
    # ---------------------------------------------------------
    # If the camera picks up a 125 BPM ghost, or if you move and the signal drops,
    # the engine mathematically ignores it. It holds your last known true heart 
    # rate until a peak re-enters your 1.5 BPM window.
    
    return previous_hr_bpm, clean_pulse, lost_lock_counter + 1, spectrum